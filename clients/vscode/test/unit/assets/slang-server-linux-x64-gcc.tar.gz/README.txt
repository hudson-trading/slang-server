Slang Server - SystemVerilog Language Server

This is a pre-built binary of slang-server.

Installation:
1. Extract this archive
2. Add the binary to your PATH, or
3. Configure your editor to use the absolute path to this binary

For more information, visit:
https://github.com/hudson-trading/slang-server

Platform: slang-server-linux-x64-gcc
Build date: $(date -u +%Y-%m-%d)
